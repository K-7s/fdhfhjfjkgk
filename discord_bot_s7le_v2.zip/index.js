const { Client, GatewayIntentBits, Collection, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildMessageReactions
    ]
});

client.commands = new Collection();
const prefix = process.env.PREFIX || '!';

// Load Commands
const commandsPath = path.join(__dirname, 'commands');
if (fs.existsSync(commandsPath)) {
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        try {
            const command = require(filePath);
            if (command.data && command.data.name) {
                client.commands.set(command.data.name, command);
            }
        } catch (err) {
            console.error(`Error loading ${file}:`, err);
        }
    }
}

// Support v14 and v15 ready event
const handleReady = () => {
    console.log(`[AUTH] Bot is online as ${client.user.tag}`);
    console.log(`[DEVELOPER] System developed and protected by s7le`);
    client.user.setActivity('Developed by s7le', { type: 3 });
};
client.once('ready', handleReady);
client.once('clientReady', handleReady);

// Interaction (Slash Command) Handler
client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;
    const command = client.commands.get(interaction.commandName);
    if (!command) return;
    try {
        await command.execute(interaction, true);
    } catch (error) {
        console.error(error);
        const replyOpts = { content: '❌ An error occurred while executing this command!', ephemeral: true };
        if (!interaction.replied && !interaction.deferred) await interaction.reply(replyOpts);
    }
});

// Message (Prefix Command & !suggest) Handler
client.on('messageCreate', async message => {
    if (message.author.bot) return;

    // Direct !suggest handling without registration requirement
    if (message.content.startsWith('!suggest')) {
        const suggestionText = message.content.slice(8).trim();
        if (!suggestionText) return message.reply('❌ الرجاء كتابة الاقتراح بعد الأمر!');
        const embed = new EmbedBuilder()
            .setColor('#2f3136')
            .setTitle('💡 اقتراح جديد')
            .setDescription(suggestionText)
            .addFields({ name: 'المقترح', value: `<@${message.author.id}>` })
            .setFooter({ text: 'System Developed by s7le', iconURL: message.client.user.displayAvatarURL() })
            .setTimestamp();
        await message.delete().catch(() => {});
        const sentMsg = await message.channel.send({ embeds: [embed] });
        await sentMsg.react('👍');
        await sentMsg.react('👎');
        return;
    }

    if (!message.content.startsWith(prefix)) return;
    const args = message.content.slice(prefix.length).trim().split(/+/);
    const commandName = args.shift().toLowerCase();
    const command = client.commands.get(commandName);
    if (!command) return;
    try {
        // Mock a basic context interface for execution similarity
        const context = {
            isSlash: false,
            message: message,
            args: args,
            guild: message.guild,
            channel: message.channel,
            user: message.author,
            member: message.member,
            reply: async (opts) => message.reply(opts)
        };
        await command.execute(context, false);
    } catch (error) {
        console.error(error);
        message.reply('❌ An error occurred while executing this prefix command!');
    }
});

client.login(process.env.TOKEN);
